package com.jama.uihook;

import android.content.Context;
import android.os.SystemClock;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Hook implements IXposedHookLoadPackage {

    // system_ui_status_bar_double_tap_to_sleep
    private static final boolean DOUBLE_TAP_SLEEP = true;

    // system_ui_status_bar_icon_* = hidden (edit to taste)
    private static final Set<String> HIDE_SLOTS = new HashSet<>(Arrays.asList(
        "airplane", "alarm_clock", "bluetooth", "bluetooth_handsfree_battery", "data_saver",
        "hotspot", "location", "mictoggle", "mic", "nfc", "vpn", "wifi", "zen"
    ));

    private static final String[] BAR_CLASSES = {
        "com.android.systemui.statusbar.phone.MiuiPhoneStatusBarView",
        "com.android.systemui.statusbar.phone.PhoneStatusBarView"
    };
    private static final String[] ICON_CTRL_CLASSES = {
        "com.android.systemui.statusbar.phone.ui.StatusBarIconControllerImpl",
        "com.android.systemui.statusbar.phone.StatusBarIconControllerImpl"
    };

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!"com.android.systemui".equals(lp.packageName)) return;
        ClassLoader cl = lp.classLoader;
        if (DOUBLE_TAP_SLEEP) hookDoubleTap(cl);
        hookIcons(cl);
    }

    private void hookDoubleTap(ClassLoader cl) {
        for (String cn : BAR_CLASSES) {
            final Class<?> c = XposedHelpers.findClassIfExists(cn, cl);
            if (c == null) continue;
            try {
                Method m = c.getMethod("dispatchTouchEvent", MotionEvent.class);
                XposedBridge.hookMethod(m, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam p) {
                        if (!c.isInstance(p.thisObject)) return;
                        final View v = (View) p.thisObject;
                        GestureDetector gd = (GestureDetector) XposedHelpers.getAdditionalInstanceField(v, "jgd");
                        if (gd == null) {
                            gd = new GestureDetector(v.getContext(), new GestureDetector.SimpleOnGestureListener() {
                                @Override
                                public boolean onDoubleTap(MotionEvent e) {
                                    sleep(v.getContext());
                                    return true;
                                }
                            });
                            XposedHelpers.setAdditionalInstanceField(v, "jgd", gd);
                        }
                        gd.onTouchEvent((MotionEvent) p.args[0]);
                    }
                });
                return;
            } catch (Throwable t) {
                XposedBridge.log("UiHook doubletap " + cn + ": " + t);
            }
        }
    }

    private static void sleep(Context ctx) {
        try {
            Object pm = ctx.getSystemService(Context.POWER_SERVICE);
            XposedHelpers.callMethod(pm, "goToSleep", SystemClock.uptimeMillis());
        } catch (Throwable t) {
            XposedBridge.log("UiHook sleep: " + t);
        }
    }

    private void hookIcons(ClassLoader cl) {
        for (String cn : ICON_CTRL_CLASSES) {
            Class<?> c = XposedHelpers.findClassIfExists(cn, cl);
            if (c == null) continue;
            try {
                XposedBridge.hookAllMethods(c, "setIconVisibility", new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam p) {
                        if (p.args.length >= 2 && p.args[0] instanceof String
                                && HIDE_SLOTS.contains(p.args[0]) && p.args[1] instanceof Boolean) {
                            p.args[1] = false;
                        }
                    }
                });
                XposedBridge.hookAllMethods(c, "setIcon", new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam p) {
                        if (p.args.length >= 1 && p.args[0] instanceof String && HIDE_SLOTS.contains(p.args[0])) {
                            try { XposedHelpers.callMethod(p.thisObject, "setIconVisibility", p.args[0], false); }
                            catch (Throwable ignored) {}
                        }
                    }
                });
            } catch (Throwable t) {
                XposedBridge.log("UiHook icons " + cn + ": " + t);
            }
        }
    }
}
