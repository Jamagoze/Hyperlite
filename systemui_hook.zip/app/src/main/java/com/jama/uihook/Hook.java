package com.jama.uihook;
import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import java.util.ArrayList;
import java.util.List;
public class Hook implements IXposedHookLoadPackage {
private static final Object[][] ICONS = {
{"vpn", 2}, {"alarm_clock", 2}, {"nfc", 2}, {"zen", 2}, {"wifi", 2}, {"demo_wifi", 2},
{"airplane", 2}, {"location", 2}, {"speakerphone", 2}, {"hotspot", 2}, {"headset", 11},
{"bluetooth", 2}, {"bluetooth_handsfree_battery", 2}, {"wireless_headset", 11}
};
private static final int DATA_SAVER_MODE = 2;
private static final boolean DOUBLE_TAP_SLEEP = true;
private static final boolean HIDE_BAR_BEFORE_SCREENSHOT = true;
private static final boolean HIDE_STRONG_TOAST = true;
private static final boolean HIDE_PERCENT_MARK = true;
private static final int NOTIF_ICONS_MAX = 1;
private static final boolean HIDE_NAV_BAR = true;
private static final boolean OLD_CONTROL_CENTER = true;
private static final int QS_COLS = 7, QS_COLS_H = 8;
private static final int QS_ROWS = 5, QS_ROWS_H = 3;
private static final int QQS_COLS = 7, QQS_COLS_H = 8;
private static final boolean CC_UNLOCK_OLD = true;
private static final boolean CC_AUTO_CLOSE = true;
private static final boolean CC_UNIMPORTANT_NOTICE = true;
private static final boolean NOTIF_FREEFORM = true;
private static final boolean MEDIA_CUSTOM_ACTIONS = true;
private static final boolean MEDIA_SQUIGGLY = true;
private static final boolean DISABLE_MULTIWIN_SWITCH = true;
private static final boolean DISABLE_BOTTOM_BAR = true;
private static final boolean UNLOCK_CLIPBOARD = true;
private static final boolean LOCK_DOUBLE_TAP = true;
private static final boolean LOCK_HIDE_STATUS_BAR = true;
private static final boolean LOCK_BLOCK_EDITOR = true;
private static final boolean LOCK_NO_BLE_TOAST = true;
private ClassLoader cl;
private interface Fn { void run(XC_MethodHook.MethodHookParam p) throws Throwable; }
private static XC_MethodHook before(final Fn f) {
return new XC_MethodHook() {
@Override protected void beforeHookedMethod(MethodHookParam p) {
try { f.run(p); } catch (Throwable t) { XposedBridge.log("UiHook: " + t); }
}
};
}
private static XC_MethodHook after(final Fn f) {
return new XC_MethodHook() {
@Override protected void afterHookedMethod(MethodHookParam p) {
try { f.run(p); } catch (Throwable t) { XposedBridge.log("UiHook: " + t); }
}
};
}
private Class<?> c(String n) { return XposedHelpers.findClassIfExists(n, cl); }
private void hk(String cn, String m, XC_MethodHook h) {
Class<?> k = c(cn);
if (k == null) { XposedBridge.log("UiHook: missing class " + cn); return; }
try {
if (XposedBridge.hookAllMethods(k, m, h).isEmpty()) XposedBridge.log("UiHook: no method " + cn + "." + m);
} catch (Throwable t) { XposedBridge.log("UiHook: " + cn + "." + m + " " + t); }
}
private void run(String name, Runnable r) {
try { r.run(); } catch (Throwable t) { XposedBridge.log("UiHook " + name + ": " + t); }
}
@Override
public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
if (!"com.android.systemui".equals(lp.packageName)) return;
cl = lp.classLoader;
run("icons", this::statusBarIcons);
if (DATA_SAVER_MODE != 0) run("dataSaver", this::dataSaver);
if (DOUBLE_TAP_SLEEP) run("doubleTap", this::doubleTapSleep);
if (HIDE_BAR_BEFORE_SCREENSHOT) run("screenshot", this::hideBarBeforeScreenshot);
if (HIDE_STRONG_TOAST) run("strongToast", this::hideStrongToast);
if (HIDE_PERCENT_MARK) run("percentMark", this::hidePercentMark);
if (NOTIF_ICONS_MAX > 0) run("notifIcons", this::notifIcons);
if (HIDE_NAV_BAR) run("navBar", this::hideNavBar);
if (OLD_CONTROL_CENTER) run("qsGrid", this::qsGrid);
if (CC_UNLOCK_OLD) run("ccStyle", this::controlCenterStyle);
if (CC_AUTO_CLOSE) run("autoClose", this::autoCollapse);
if (CC_UNIMPORTANT_NOTICE) run("unimportant", this::unimportantNotification);
if (NOTIF_FREEFORM) run("freeform", () -> hk("com.android.systemui.statusbar.notification.row.MiuiExpandableNotificationRow",
"updateMiniWindowBar", after(p -> XposedHelpers.setObjectField(p.thisObject, "mCanSlide", true))));
if (MEDIA_CUSTOM_ACTIONS) run("mediaActions", this::unlockCustomActions);
if (MEDIA_SQUIGGLY) run("squiggly", this::squiggly);
if (DISABLE_MULTIWIN_SWITCH) run("multiwin", () -> hk("com.android.wm.shell.miuimultiwinswitch.miuiwindowdecor.MiuiDotView", "onDraw", XC_MethodReplacement.returnConstant(null)));
if (DISABLE_BOTTOM_BAR) run("bottomBar", () -> hk("com.android.wm.shell.miuimultiwinswitch.miuiwindowdecor.MiuiBaseWindowDecoration", "createBottomCaption", XC_MethodReplacement.returnConstant(null)));
if (UNLOCK_CLIPBOARD) run("clipboard", this::unlockClipboard);
if (LOCK_DOUBLE_TAP) run("lockDoubleTap", this::lockDoubleTap);
if (LOCK_HIDE_STATUS_BAR) run("lockStatusBar", this::lockHideStatusBar);
if (LOCK_BLOCK_EDITOR) run("lockEditor", () -> hk("com.android.keyguard.KeyguardEditorHelper", "checkIfStartEditActivity", XC_MethodReplacement.returnConstant(null)));
if (LOCK_NO_BLE_TOAST) run("bleToast", this::noBleToast);
}
@SuppressWarnings("unchecked")
private void statusBarIcons() {
Class<?> u = c("com.android.systemui.statusbar.phone.MiuiIconManagerUtils");
if (u == null) return;
List<String> bar = new ArrayList<>((List<String>) XposedHelpers.getStaticObjectField(u, "RIGHT_BLOCK_LIST"));
List<String> cc = new ArrayList<>((List<String>) XposedHelpers.getStaticObjectField(u, "CONTROL_CENTER_BLOCK_LIST"));
for (Object[] e : ICONS) {
String n = (String) e[0];
int v = (Integer) e[1];
switch (v) {
case 1: bar.remove(n); cc.remove(n); break;
case 12: bar.remove(n); if (!cc.contains(n)) cc.add(n); break;
case 11: if (!bar.contains(n)) bar.add(n); cc.remove(n); break;
case 2: if (!bar.contains(n)) bar.add(n); if (!cc.contains(n)) cc.add(n); break;
default: break;
}
}
XposedHelpers.setStaticObjectField(u, "RIGHT_BLOCK_LIST", bar);
XposedHelpers.setStaticObjectField(u, "CONTROL_CENTER_BLOCK_LIST", cc);
}
private void dataSaver() {
hk("com.android.systemui.statusbar.phone.PhoneStatusBarPolicy", "onDataSaverChanged", before(p -> {
if (DATA_SAVER_MODE == 1) p.args[0] = true;
else if (DATA_SAVER_MODE == 2) p.args[0] = false;
}));
}
private void attachDoubleTap(final View view, final boolean lockOnly) {
final long[] last = {0L};
final float[] lx = {0f}, ly = {0f};
view.setOnTouchListener(new View.OnTouchListener() {
@Override public boolean onTouch(View v, MotionEvent e) {
if (e.getAction() != MotionEvent.ACTION_DOWN) return false;
long now = System.currentTimeMillis();
if (now - last[0] < 250L && Math.abs(e.getX() - lx[0]) < 100f && Math.abs(e.getY() - ly[0]) < 100f) {
boolean ok = true;
if (lockOnly) {
KeyguardManager km = (KeyguardManager) v.getContext().getSystemService(Context.KEYGUARD_SERVICE);
ok = km.isKeyguardLocked();
}
if (ok) XposedHelpers.callMethod(v.getContext().getSystemService(Context.POWER_SERVICE), "goToSleep", SystemClock.uptimeMillis());
last[0] = 0L; lx[0] = 0f; ly[0] = 0f;
} else {
last[0] = now; lx[0] = e.getX(); ly[0] = e.getY();
}
v.performClick();
return false;
}
});
}
private void doubleTapSleep() {
hk("com.android.systemui.statusbar.phone.MiuiPhoneStatusBarView", "onFinishInflate",
before(p -> attachDoubleTap((View) p.thisObject, false)));
}
private void lockDoubleTap() {
hk("com.android.systemui.shade.NotificationsQuickSettingsContainer", "onFinishInflate",
before(p -> attachDoubleTap((View) p.thisObject, true)));
}
private void hideBarBeforeScreenshot() {
XC_MethodHook h = after(p -> {
final View view = (View) p.args[0];
BroadcastReceiver br = new BroadcastReceiver() {
@Override public void onReceive(Context ctx, Intent i) {
if ("miui.intent.TAKE_SCREENSHOT".equals(i.getAction())) {
boolean finished = i.getBooleanExtra("IsFinished", true);
view.setVisibility(finished ? View.VISIBLE : View.INVISIBLE);
}
}
};
view.getContext().registerReceiver(br, new IntentFilter("miui.intent.TAKE_SCREENSHOT"));
});
String k = "com.android.systemui.statusbar.phone.MiuiCollapsedStatusBarFragment";
Class<?> kc = c(k);
if (kc == null) return;
boolean has = false;
for (java.lang.reflect.Method m : kc.getDeclaredMethods()) if (m.getName().equals("initMiuiViewsOnViewCreated")) has = true;
hk(k, has ? "initMiuiViewsOnViewCreated" : "onViewCreated", h);
}
private void hideStrongToast() {
hk("com.android.systemui.toast.MIUIStrongToast", "onAttachedToWindow", after(p ->
((FrameLayout) p.thisObject).getViewTreeObserver().addOnPreDrawListener(() -> false)));
}
private void hidePercentMark() {
hk("com.android.systemui.statusbar.views.MiuiBatteryMeterView", "updateAll", after(p -> {
Object v = XposedHelpers.getObjectField(p.thisObject, "mBatteryPercentMarkView");
if (v instanceof TextView) ((TextView) v).setTextSize(0f);
}));
}
private void notifIcons() {
final String k = "com.android.systemui.statusbar.phone.NotificationIconContainer";
XC_MethodHook h = before(p -> {
XposedHelpers.setObjectField(p.thisObject, "mMaxStaticIcons", NOTIF_ICONS_MAX);
XposedHelpers.setObjectField(p.thisObject, "mIsStaticLayout", true);
});
hk(k, "calculateIconXTranslations", h);
hk(k, "onMeasure", h);
hk(k, "calculateWidthFor", before(p -> XposedHelpers.setObjectField(p.thisObject, "mMaxIconsOnLockscreen", NOTIF_ICONS_MAX)));
}
private void hideNavBar() {
hk("com.android.systemui.navigationbar.NavigationBarController", "createNavigationBar", after(p -> {
android.view.Display d = (android.view.Display) p.args[0];
XposedHelpers.callMethod(p.thisObject, "removeNavigationBar", d.getDisplayId());
Context ctx = (Context) XposedHelpers.getObjectField(p.thisObject, "mContext");
try {
if (Settings.Global.getInt(ctx.getContentResolver(), "hide_gesture_line") == 1)
Settings.Global.putInt(ctx.getContentResolver(), "hide_gesture_line", 0);
} catch (Settings.SettingNotFoundException ignored) {}
}));
hk("com.android.systemui.statusbar.phone.MiuiDockIndicatorService", "onNavigationModeChanged", before(p -> {
XposedHelpers.setObjectField(p.thisObject, "mNavMode", p.args[0]);
if (XposedHelpers.getObjectField(p.thisObject, "mNavigationBarView") != null)
XposedHelpers.callMethod(p.thisObject, "setNavigationBarView");
else
XposedHelpers.callMethod(p.thisObject, "checkAndApplyNavigationMode");
p.setResult(null);
}));
}
private static boolean portrait(Object view) {
return ((ViewGroup) view).getContext().getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT;
}
private void qsGrid() {
hk("com.android.systemui.qs.MiuiTileLayout", "layoutTileRecords", after(p -> {
if (p.args.length != 1) return;
XposedHelpers.setIntField(p.thisObject, "mColumns", portrait(p.thisObject) ? QS_COLS : QS_COLS_H);
}));
hk("com.android.systemui.qs.MiuiTileLayout", "updateResources", after(p -> {
XposedHelpers.setIntField(p.thisObject, "mMaxAllowedRows", portrait(p.thisObject) ? QS_ROWS : QS_ROWS_H);
((ViewGroup) p.thisObject).requestLayout();
}));
hk("com.android.systemui.qs.MiuiQuickQSPanel", "setMaxTiles", before(p -> {
if (p.args.length == 1) p.args[0] = portrait(p.thisObject) ? QQS_COLS : QQS_COLS_H;
}));
}
private void controlCenterStyle() {
Class<?> k = c("com.android.systemui.controlcenter.policy.ControlCenterControllerImpl");
if (k != null) XposedBridge.hookAllConstructors(k, after(p -> XposedHelpers.setBooleanField(p.thisObject, "forceUseControlCenterPanel", false)));
hk("com.miui.interfaces.SettingsObserver", "setValue$default", before(p -> {
if (p.args.length > 2 && "force_use_control_panel".equals(p.args[1])) p.args[2] = 0;
}));
}
private void autoCollapse() {
XC_MethodHook h = after(p -> {
Object st = XposedHelpers.callMethod(p.thisObject, "getState");
if (XposedHelpers.getIntField(st, "state") != 0) {
String spec = (String) XposedHelpers.callMethod(p.thisObject, "getTileSpec");
if (!"edit".equals(spec)) XposedHelpers.callMethod(XposedHelpers.getObjectField(p.thisObject, "mHost"), "collapsePanels");
}
});
hk("com.android.systemui.qs.tileimpl.QSTileImpl", "click", h);
}
private void unimportantNotification() {
hk("com.android.systemui.statusbar.notification.collection.coordinator.FoldCoordinator$shadeExpansionListener$1",
"onPanelExpansionChanged", before(p -> {
Object fc = XposedHelpers.getObjectField(p.thisObject, "this$0");
XposedHelpers.setObjectField(fc, "mPendingNotifications", new ArrayList<Object>());
}));
Class<?> fc = c("com.android.systemui.statusbar.notification.collection.coordinator.FoldCoordinator");
boolean ok = false;
if (fc != null) {
for (java.lang.reflect.Method m : fc.getDeclaredMethods()) if (m.getName().equals("access$shouldIgnoreEntry")) ok = true;
}
if (ok) {
hk("com.android.systemui.statusbar.notification.collection.coordinator.FoldCoordinator", "access$shouldIgnoreEntry", after(p -> p.setResult(true)));
} else {
String u = c("com.android.systemui.statusbar.notification.utils.NotificationUtil") != null
? "com.android.systemui.statusbar.notification.utils.NotificationUtil"
: "com.android.systemui.statusbar.notification.NotificationUtil";
hk(u, "shouldIgnoreEntry", after(p -> p.setResult(true)));
}
}
private void unlockCustomActions() {
hk("com.android.systemui.media.controls.pipeline.MediaDataManager$createActionsFromState$customActions$1", "invoke", before(p -> {
Class<?> h = c("com.android.systemui.statusbar.notification.NotificationSettingsManager$Holder");
Object inst = XposedHelpers.getStaticObjectField(h, "INSTANCE");
XposedHelpers.setObjectField(inst, "mHiddenCustomActionsList", new ArrayList<Object>());
}));
}
private void squiggly() {
Class<?> vh = c("com.android.systemui.media.controls.models.player.MediaViewHolder");
if (vh == null) return;
XposedBridge.hookAllConstructors(vh, after(p -> {
Object bar = XposedHelpers.getObjectField(p.thisObject, "seekBar");
Object sq = XposedHelpers.newInstance(c("com.android.systemui.media.controls.ui.SquigglyProgress"));
((android.widget.SeekBar) bar).setProgressDrawable((android.graphics.drawable.Drawable) sq);
}));
}
private void unlockClipboard() {
Class<?> k = c("com.android.systemui.clipboardoverlay.ClipboardListener");
if (k == null) return;
boolean hasList = false;
for (java.lang.reflect.Field f : k.getDeclaredFields()) if (f.getName().equals("sCtsTestPkgList")) hasList = true;
if (hasList) {
hk("com.android.systemui.clipboardoverlay.ClipboardListener", "onPrimaryClipChanged", before(p -> {
Object cm = XposedHelpers.getObjectField(p.thisObject, "mClipboardManager");
String src = (String) XposedHelpers.callMethod(cm, "getPrimaryClipSource");
@SuppressWarnings("unchecked")
List<String> old = (List<String>) XposedHelpers.getObjectField(p.thisObject, "sCtsTestPkgList");
List<String> nl = new ArrayList<>(old);
if (src != null && !nl.contains(src)) nl.add(src);
XposedHelpers.setObjectField(p.thisObject, "sCtsTestPkgList", nl);
}));
} else {
hk("com.android.systemui.clipboardoverlay.ClipboardListener", "start", before(p -> {
android.content.ClipboardManager cm = (android.content.ClipboardManager) XposedHelpers.getObjectField(p.thisObject, "mClipboardManager");
cm.addPrimaryClipChangedListener((android.content.ClipboardManager.OnPrimaryClipChangedListener) p.thisObject);
p.setResult(null);
}));
}
}
private void lockHideStatusBar() {
hk("com.android.systemui.statusbar.phone.CentralSurfacesImpl", "updateIsKeyguard", after(p -> {
Object shade = XposedHelpers.getObjectField(p.thisObject, "mShadeController");
Object npvc = XposedHelpers.getObjectField(shade, "mNotificationPanelViewController");
Object bar = XposedHelpers.getObjectField(npvc, "mKeyguardStatusBar");
((View) bar).setTranslationY(-999f);
}));
}
private void noBleToast() {
XposedHelpers.findAndHookMethod(Toast.class, "makeText", Context.class, int.class, int.class, after(p -> {
try {
String n = ((Context) p.args[0]).getResources().getResourceName((Integer) p.args[1]);
if ("com.android.systemui:string/miui_keyguard_ble_unlock_succeed_msg".equals(n) && p.getResult() != null)
XposedHelpers.setAdditionalInstanceField(p.getResult(), "jblock", Boolean.TRUE);
} catch (Throwable ignored) {}
}));
XposedHelpers.findAndHookMethod(Toast.class, "show", before(p -> {
if (XposedHelpers.getAdditionalInstanceField(p.thisObject, "jblock") != null) p.setResult(null);
}));
}
}
