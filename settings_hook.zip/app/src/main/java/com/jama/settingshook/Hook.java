package com.jama.settingshook;

import dalvik.system.DexFile;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import java.io.File;
import java.io.FileWriter;
import java.lang.reflect.Method;
import java.util.Enumeration;

public class Hook implements IXposedHookLoadPackage {

    // system_settings_international_build
    private static final boolean INTERNATIONAL_BUILD_OFF = true;
    // writes <settings data>/cache/settings_classes.txt once
    private static final boolean DUMP_CLASSES = true;

    private static final String[] KEYS = {
        "Freezer", "MaxFps", "Fps", "SpeedMode", "Develop", "AiImage", "Memc", "SuperResolution",
        "Sr", "PadArea", "Pad", "Accessibility", "UnknownSource", "InstallUnknown", "Notification",
        "UiMode", "SafeWifi", "Wifi", "Permission", "AppPermission", "Anti", "Question", "Feature"
    };

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!"com.android.settings".equals(lp.packageName)) return;
        if (INTERNATIONAL_BUILD_OFF) {
            try {
                Class<?> b = XposedHelpers.findClass("miui.os.Build", lp.classLoader);
                XposedHelpers.setStaticBooleanField(b, "IS_INTERNATIONAL_BUILD", false);
            } catch (Throwable t) {
                XposedBridge.log("SettingsHook intl: " + t);
            }
        }
        if (DUMP_CLASSES) dump(lp);
    }

    private void dump(final XC_LoadPackage.LoadPackageParam lp) {
        final File out = new File(lp.appInfo.dataDir + "/cache/settings_classes.txt");
        if (out.exists()) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    DexFile df = new DexFile(lp.appInfo.sourceDir);
                    FileWriter w = new FileWriter(out);
                    Enumeration<String> e = df.entries();
                    int n = 0;
                    while (e.hasMoreElements() && n < 900) {
                        String cn = e.nextElement();
                        if (!cn.startsWith("com.android.settings") && !cn.startsWith("com.miui")) continue;
                        boolean hit = false;
                        for (String k : KEYS) if (cn.contains(k)) { hit = true; break; }
                        if (!hit) continue;
                        n++;
                        w.write(cn + "\n");
                        try {
                            Class<?> c = Class.forName(cn, false, lp.classLoader);
                            for (Method m : c.getDeclaredMethods()) {
                                StringBuilder sb = new StringBuilder("  ").append(m.getReturnType().getSimpleName())
                                        .append(' ').append(m.getName()).append('(');
                                Class<?>[] pt = m.getParameterTypes();
                                for (int i = 0; i < pt.length; i++) { if (i > 0) sb.append(','); sb.append(pt[i].getSimpleName()); }
                                w.write(sb.append(")\n").toString());
                            }
                        } catch (Throwable ignored) {}
                    }
                    w.close();
                    out.setReadable(true, false);
                    XposedBridge.log("SettingsHook: wrote " + out);
                } catch (Throwable t) {
                    XposedBridge.log("SettingsHook dump: " + t);
                }
            }
        }).start();
    }
}
