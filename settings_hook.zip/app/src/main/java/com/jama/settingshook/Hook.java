package com.jama.settingshook;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.TextView;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import java.lang.reflect.Field;
import java.util.List;
public class Hook implements IXposedHookLoadPackage {
private static final boolean INTERNATIONAL_BUILD = true;
private static final boolean UNLOCK_UI_MODE = true;
private static final boolean SAFE_WIFI = true;
private static final boolean SPEED_MODE = true;
private static final boolean MAX_FPS = true;
private static final boolean APPS_FREEZER = true;
private static final boolean OVERLAY_PERMISSION = true;
private static final boolean ACCESSIBILITY_PERMISSION = true;
private static final boolean NO_UNKNOWN_VERIFY = true;
private static final boolean ANTI_QUES = true;
private static final boolean AI_IMAGE = true;
private static final boolean MORE_NOTIFICATION = true;
private ClassLoader cl;
private interface Fn { void run(XC_MethodHook.MethodHookParam p) throws Throwable; }
private static XC_MethodHook before(final Fn f) {
return new XC_MethodHook() {
@Override protected void beforeHookedMethod(MethodHookParam p) {
try { f.run(p); } catch (Throwable t) { XposedBridge.log("SettingsHook: " + t); }
}
};
}
private static XC_MethodHook after(final Fn f) {
return new XC_MethodHook() {
@Override protected void afterHookedMethod(MethodHookParam p) {
try { f.run(p); } catch (Throwable t) { XposedBridge.log("SettingsHook: " + t); }
}
};
}
private Class<?> c(String n) { return XposedHelpers.findClassIfExists(n, cl); }
private void hk(String cn, String m, XC_MethodHook h) {
Class<?> k = c(cn);
if (k == null) { XposedBridge.log("SettingsHook: missing class " + cn); return; }
try {
if (XposedBridge.hookAllMethods(k, m, h).isEmpty()) XposedBridge.log("SettingsHook: no method " + cn + "." + m);
} catch (Throwable t) { XposedBridge.log("SettingsHook: " + cn + "." + m + " " + t); }
}
private void run(String name, Runnable r) {
try { r.run(); } catch (Throwable t) { XposedBridge.log("SettingsHook " + name + ": " + t); }
}
@Override
public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
if (!"com.android.settings".equals(lp.packageName)) return;
cl = lp.classLoader;
if (INTERNATIONAL_BUILD) run("intl", () -> setIntl(true));
if (UNLOCK_UI_MODE) run("uiMode", this::uiMode);
if (SAFE_WIFI) run("wifi", this::wifiPassword);
if (SPEED_MODE) run("speed", () -> hk("com.android.settings.development.SpeedModeToolsPreferenceController", "getAvailabilityStatus", XC_MethodReplacement.returnConstant(0)));
if (MAX_FPS) run("fps", () -> hk("com.android.settings.development.ForcePeakRefreshRatePreferenceController", "isAvailable", after(p -> p.setResult(true))));
if (APPS_FREEZER) run("freezer", () -> hk("com.android.settings.development.CachedAppsFreezerPreferenceController", "isAvailable", after(p -> p.setResult(true))));
if (OVERLAY_PERMISSION) run("overlay", this::overlayPermission);
if (ACCESSIBILITY_PERMISSION) run("accessibility", this::accessibilityPermission);
if (NO_UNKNOWN_VERIFY) run("unknownVerify", () -> hk("com.android.settings.applications.appinfo.ExternalSourcesDetails", "doUnknownSourceVerify", XC_MethodReplacement.returnConstant(false)));
if (ANTI_QUES) run("antiQues", this::antiQues);
if (AI_IMAGE) run("aiImage", this::aiImage);
if (MORE_NOTIFICATION) run("moreNotif", this::moreNotification);
}
private void setIntl(boolean v) {
Class<?> b = c("miui.os.Build");
if (b != null) XposedHelpers.setStaticBooleanField(b, "IS_INTERNATIONAL_BUILD", v);
}
private boolean getIntl() {
Class<?> b = c("miui.os.Build");
return b != null && XposedHelpers.getStaticBooleanField(b, "IS_INTERNATIONAL_BUILD");
}
private void uiMode() {
hk("com.android.settings.utils.SettingsFeatures", "shouldShowAutoUIModeSetting", before(p -> {
Class<?> sp = XposedHelpers.findClass("android.os.SystemProperties", null);
boolean on = (Boolean) XposedHelpers.callStaticMethod(sp, "getBoolean", "persist.miui.auto_ui_enable", false);
if (on) p.setResult(true);
}));
}
private void wifiPassword() {
final String[] key = new String[1];
hk("com.android.settings.wifi.SavedAccessPointPreference", "onBindViewHolder", after(p -> {
View view = (View) XposedHelpers.getObjectField(p.thisObject, "mView");
int id = view.getResources().getIdentifier("btn_delete", "id", "com.android.settings");
Button b = view.findViewById(id);
if (b != null) b.setText("Password");
}));
hk("miuix.appcompat.app.AlertDialog$Builder", "setMessage", before(p -> {
if (key[0] != null && p.args.length == 1 && p.args[0] instanceof CharSequence)
p.args[0] = p.args[0] + "\nPassword: " + key[0];
}));
hk("miuix.appcompat.app.AlertDialog", "onCreate", after(p -> {
if (key[0] != null) {
Object tv = XposedHelpers.callMethod(p.thisObject, "getMessageView");
if (tv instanceof TextView) ((TextView) tv).setTextIsSelectable(true);
}
}));
hk("com.android.settings.wifi.MiuiSavedAccessPointsWifiSettings", "showDeleteDialog", new XC_MethodHook() {
@Override protected void beforeHookedMethod(MethodHookParam p) {
try {
Object entry = p.args[0];
if ((Boolean) XposedHelpers.callMethod(entry, "canShare")) {
Object wm = XposedHelpers.getObjectField(p.thisObject, "mWifiManager");
Object conf = XposedHelpers.callMethod(entry, "getWifiConfiguration");
Class<?> u = XposedHelpers.findClass("com.android.settings.wifi.dpp.WifiDppUtils", cl);
String k = (String) XposedHelpers.callStaticMethod(u, "getPresharedKey", wm, conf);
key[0] = (String) XposedHelpers.callStaticMethod(u, "removeFirstAndLastDoubleQuotes", k);
}
} catch (Throwable t) { XposedBridge.log("SettingsHook wifi: " + t); }
}
@Override protected void afterHookedMethod(MethodHookParam p) {
try {
if ((Boolean) XposedHelpers.callMethod(p.args[0], "canShare")) key[0] = null;
} catch (Throwable ignored) {}
}
});
}
private void overlayPermission() {
hk("com.android.settings.SettingsActivity", "redirectTabletActivity", before(p -> {
Intent i = ((Activity) p.thisObject).getIntent();
if (!Settings.ACTION_MANAGE_OVERLAY_PERMISSION.equals(i.getAction()) || i.getData() == null
|| !"package".equals(i.getData().getScheme())) return;
Class<?> k = p.thisObject.getClass();
while (k != null) {
try {
Field f = k.getDeclaredField("initialFragmentName");
f.setAccessible(true);
f.set(p.thisObject, "com.android.settings.applications.appinfo.DrawOverlayDetails");
break;
} catch (NoSuchFieldException e) { k = k.getSuperclass(); }
}
}));
}
private void accessibilityPermission() {
hk("com.android.settings.SettingsActivity", "onCreate", after(p -> {
if (p.args.length != 1 || !(p.args[0] == null || p.args[0] instanceof Bundle)) return;
Activity a = (Activity) p.thisObject;
Intent intent = a.getIntent();
if (intent == null || !"android.settings.ACCESSIBILITY_SETTINGS".equals(intent.getAction())) return;
String pkg = (String) XposedHelpers.getObjectField(intent, "mSenderPackageName");
if (pkg == null) return;
PackageManager pm = a.getPackageManager();
AccessibilityManager am = (AccessibilityManager)a.getSystemService("accessibility");
String service = null, summary = null;
List<AccessibilityServiceInfo> list = am.getInstalledAccessibilityServiceList();
for (AccessibilityServiceInfo info : list) {
ServiceInfo si = info.getResolveInfo().serviceInfo;
if (pkg.equals(si.packageName)) { service = si.name; summary = info.loadDescription(pm); }
}
if (service == null) return;
String appName = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
Intent sub = new Intent(a, c("com.android.settings.SubSettings"));
sub.setAction("android.intent.action.MAIN");
sub.putExtra(":settings:show_fragment_title", appName);
sub.putExtra(":settings:source_metrics", 0);
sub.putExtra(":settings:show_fragment_title_resid", -1);
sub.putExtra(":settings:show_fragment", "com.android.settings.accessibility.VolumeShortcutToggleAccessibilityServicePreferenceFragment");
Bundle args = new Bundle();
args.putParcelable("component_name", new ComponentName(pkg, service));
args.putString("package", pkg);
args.putString("preference_key", pkg + "/" + service);
args.putString("summary", summary);
sub.putExtra(":settings:show_fragment_args", args);
a.startActivity(sub);
}));
}
private void antiQues() {
XC_MethodHook swap = new XC_MethodHook() {
@Override protected void beforeHookedMethod(MethodHookParam p) {
try { p.setObjectExtra("orig", getIntl()); setIntl(true); } catch (Throwable ignored) {}
}
@Override protected void afterHookedMethod(MethodHookParam p) {
try { Object o = p.getObjectExtra("orig"); if (o != null) setIntl((Boolean) o); } catch (Throwable ignored) {}
}
};
hk("com.android.settings.MiuiDeviceNameEditFragment", "onSave", swap);
hk("com.android.settings.wifi.EditTetherFragment", "onSave", swap);
hk("com.android.settings.DeviceNameCheckManager", "getDeviceNameCheckResult", swap);
hk("com.android.settings.bluetooth.MiuiBTUtils", "isSupportNameComplianceCheck", XC_MethodReplacement.returnConstant(false));
hk("com.android.settings.bluetooth.MiuiBTUtils", "isInternationalBuild", XC_MethodReplacement.returnConstant(true));
}
private void aiImage() {
String k = "com.android.settings.display.ScreenEnhanceEngineStatusCheck";
String[] names = {"getSrForVideoStatus", "getSrForImageStatus", "getS2hStatus", "isSrForVideoSupport",
"isSrForImageSupport", "isS2hSupport", "isAiSupport", "isMemcSupport"};
for (String n : names) hk(k, n, XC_MethodReplacement.returnConstant(true));
}
private void moreNotification() {
hk("com.android.settings.notification.BaseNotificationSettings", "setPrefVisible", before(p -> {
Object pref = p.args[0];
if (pref == null) return;
String key = (String) XposedHelpers.callMethod(pref, "getKey");
if ("importance".equals(key) || "badge".equals(key) || "allow_keyguard".equals(key)) p.args[1] = true;
}));
}
}
