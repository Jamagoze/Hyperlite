package com.jama.pluginhook;

import android.content.pm.ApplicationInfo;

import dalvik.system.DexFile;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import java.io.File;
import java.io.FileWriter;
import java.lang.reflect.Method;
import java.util.Enumeration;

public class Hook implements IXposedHookLoadPackage {

    private static final String PLUGIN_PKG = "miui.systemui.plugin";
    // writes <systemui data>/cache/plugin_classes.txt once
    private static final boolean DUMP_CLASSES = true;

    private static final String[] KEYS = {
        "ControlCenter", "Qs", "Tile", "MediaControl", "Media", "Notification", "Volume", "Blur",
        "LockScreen", "Lockscreen", "Clipboard", "Brightness", "Header", "Theme", "Monet"
    };

    private static String dataDir;
    private static volatile boolean done;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!"com.android.systemui".equals(lp.packageName)) return;
        dataDir = lp.appInfo.dataDir;
        String[] factories = {
            "com.android.systemui.shared.plugins.PluginInstance$Factory",
            "com.android.systemui.shared.plugins.PluginInstance$PluginFactory"
        };
        for (String fn : factories) {
            Class<?> f = XposedHelpers.findClassIfExists(fn, lp.classLoader);
            if (f == null) continue;
            try {
                XposedBridge.hookAllMethods(f, "getClassLoader", new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam p) {
                        if (p.args.length > 0 && p.args[0] instanceof ApplicationInfo
                                && p.getResult() instanceof ClassLoader) {
                            ApplicationInfo ai = (ApplicationInfo) p.args[0];
                            if (PLUGIN_PKG.equals(ai.packageName)) onPlugin(ai, (ClassLoader) p.getResult());
                        }
                    }
                });
            } catch (Throwable t) {
                XposedBridge.log("PluginHook " + fn + ": " + t);
            }
        }
    }

    // Plugin classes are available here: hook them with XposedHelpers.findClass(name, cl)
    private void onPlugin(ApplicationInfo ai, final ClassLoader cl) {
        if (done) return;
        done = true;
        XposedBridge.log("PluginHook: plugin loader ready " + ai.sourceDir);
        if (DUMP_CLASSES) dump(ai, cl);
    }

    private void dump(final ApplicationInfo ai, final ClassLoader cl) {
        final File out = new File(dataDir + "/cache/plugin_classes.txt");
        if (out.exists()) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    DexFile df = new DexFile(ai.sourceDir);
                    FileWriter w = new FileWriter(out);
                    Enumeration<String> e = df.entries();
                    int n = 0;
                    while (e.hasMoreElements() && n < 900) {
                        String cn = e.nextElement();
                        boolean hit = false;
                        for (String k : KEYS) if (cn.contains(k)) { hit = true; break; }
                        if (!hit) continue;
                        n++;
                        w.write(cn + "\n");
                        try {
                            Class<?> c = Class.forName(cn, false, cl);
                            for (Method m : c.getDeclaredMethods()) {
                                StringBuilder sb = new StringBuilder("  ").append(m.getReturnType().getSimpleName())
                                        .append(' ').append(m.getName()).append('(');
                                Class<?>[] pt = m.getParameterTypes();
                                for (int i = 0; i < pt.length; i++) { if (i > 0) sb.append(','); sb.append(pt[i].getSimpleName()); }
                                w.write(sb.append(")\n").toString());
                            }
                        } catch (Throwable ignored) {}
                    }
                    w.close();
                    out.setReadable(true, false);
                    XposedBridge.log("PluginHook: wrote " + out);
                } catch (Throwable t) {
                    XposedBridge.log("PluginHook dump: " + t);
                }
            }
        }).start();
    }
}
