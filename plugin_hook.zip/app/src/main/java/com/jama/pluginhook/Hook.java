package com.jama.pluginhook;

import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class Hook implements IXposedHookLoadPackage {

    // ---- values from the HyperCeiler config ----
    private static final boolean HIDE_EDIT_BUTTON = true;      // system_ui_control_center_hide_edit_botton
    private static final boolean TILE_SUPER_BLUR = true;       // system_ui_control_center_tile_super_blur
    private static final boolean DEFAULT_PLUGIN_THEME = true;  // system_ui_other_default_plugin_theme

    private static final String PLUGIN_PKG = "miui.systemui.plugin";
    private static final String MODE_OS1 = "MainPanelModeController$MainPanelMode";
    private static final String MODE_OS2 = "MainPanelController$Mode";

    private interface Fn { void run(XC_MethodHook.MethodHookParam p) throws Throwable; }

    private static XC_MethodHook before(final Fn f) {
        return new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                try { f.run(p); } catch (Throwable t) { XposedBridge.log("PluginHook: " + t); }
            }
        };
    }

    private static XC_MethodHook after(final Fn f) {
        return new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                try { f.run(p); } catch (Throwable t) { XposedBridge.log("PluginHook: " + t); }
            }
        };
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!"com.android.systemui".equals(lp.packageName)) return;
        Class<?> f = XposedHelpers.findClassIfExists("com.android.systemui.shared.plugins.PluginInstance$PluginFactory", lp.classLoader);
        if (f == null) { XposedBridge.log("PluginHook: PluginFactory not found"); return; }
        XposedBridge.hookAllMethods(f, "createPluginContext", after(p -> {
            if (!(p.getResult() instanceof ContextWrapper)) return;
            Object cn = XposedHelpers.getObjectField(p.thisObject, "mComponentName");
            if (!(cn instanceof ComponentName)) return;
            ComponentName comp = (ComponentName) cn;
            if (!PLUGIN_PKG.equals(comp.getPackageName())) return;
            ClassLoader pcl = ((ContextWrapper) p.getResult()).getClassLoader();
            onPlugin(comp.getClassName(), pcl);
        }));
    }

    private void onPlugin(String cls, ClassLoader cl) {
        boolean cc = cls.equals("miui.systemui.quicksettings.LocalMiuiQSTilePlugin")
                || cls.equals("miui.systemui.controlcenter.MiuiControlCenter");
        boolean volume = cls.equals("miui.systemui.volume.VolumeDialogPlugin");
        if (!cc && !volume) return;
        XposedBridge.log("PluginHook: plugin loaded " + cls);
        if (cc && HIDE_EDIT_BUTTON) guard("editButton", () -> hideEditButton(cl));
        if (cc && TILE_SUPER_BLUR) guard("superBlur", () -> tileSuperBlur(cl));
        if (DEFAULT_PLUGIN_THEME) guard("defaultTheme", () -> defaultTheme(cl));
    }

    private void guard(String n, Runnable r) {
        try { r.run(); } catch (Throwable t) { XposedBridge.log("PluginHook " + n + ": " + t); }
    }

    private static void hookAll(ClassLoader cl, String cn, String m, XC_MethodHook h) {
        Class<?> k = XposedHelpers.findClassIfExists(cn, cl);
        if (k == null) { XposedBridge.log("PluginHook: missing class " + cn); return; }
        try {
            if (XposedBridge.hookAllMethods(k, m, h).isEmpty()) XposedBridge.log("PluginHook: no method " + cn + "." + m);
        } catch (Throwable t) { XposedBridge.log("PluginHook: " + cn + "." + m + " " + t); }
    }

    // HyperCeiler: HideEditButton
    private void hideEditButton(ClassLoader cl) {
        hookAll(cl, "miui.systemui.controlcenter.panel.main.qs.EditButtonController", "available", XC_MethodReplacement.returnConstant(false));
    }

    // HyperCeiler: DefaultPluginTheme
    private void defaultTheme(ClassLoader cl) {
        hookAll(cl, "miui.systemui.util.ThemeUtils", "getDefaultPluginTheme", after(p -> p.setResult(true)));
    }

    // ---------------- HyperCeiler: QsTileSuperBlur ----------------
    private static int[] listItemsBlend, seekbarFgBlend, ringerIconBlend, seekbarRingerBgBlend;
    private static Class<?> miBlur;
    private static Object NORMAL, EDIT;
    private static final Map<View, Boolean> standardBtn = new ConcurrentHashMap<>();
    private static final Map<View, Boolean> iconState = new ConcurrentHashMap<>();

    private void tileSuperBlur(ClassLoader cl) {
        final boolean os1 = XposedHelpers.findClassIfExists("miui.systemui.controlcenter.panel.main.MainPanelController$Mode", cl) == null;
        final String modeName = "miui.systemui.controlcenter.panel.main." + (os1 ? MODE_OS1 : MODE_OS2);
        Class<?> mode = XposedHelpers.findClass(modeName, cl);
        miBlur = XposedHelpers.findClass("miui.systemui.util.MiBlurCompat", cl);
        final String pre = os1 ? "MODE_" : "";
        NORMAL = XposedHelpers.getStaticObjectField(mode, pre + "NORMAL");
        EDIT = XposedHelpers.getStaticObjectField(mode, pre + "EDIT");

        Class<?> tile = XposedHelpers.findClass("miui.systemui.controlcenter.qs.tileview.QSTileItemView", cl);

        try {
            XposedBridge.hookAllConstructors(tile, after(p -> {
                if (p.args.length != 4) return;
                initRes((Context) p.args[0]);
                Object state = XposedHelpers.getObjectField(p.thisObject, "state");
                if (state != null) updateBlend((View) XposedHelpers.callMethod(p.thisObject, "getBlendTarget"), state, false);
            }));
        } catch (Throwable t) { XposedBridge.log("PluginHook tile ctor: " + t); }

        hookAll(cl, "miui.systemui.controlcenter.qs.tileview.QSTileItemView", "onModeChanged", before(p -> {
            Object m = p.args[0];
            if (m == null) return;
            XposedHelpers.setObjectField(p.thisObject, "mode", m);
            if (m == EDIT) {
                Object icon = XposedHelpers.callMethod(p.thisObject, "getIcon");
                updateBlend((View) XposedHelpers.callMethod(icon, "getIcon"), null, true);
            } else {
                Object state = XposedHelpers.getObjectField(p.thisObject, "state");
                if (state != null) updateBlend((View) XposedHelpers.callMethod(p.thisObject, "getBlendTarget"), state, false);
            }
            XposedHelpers.callMethod(p.thisObject, "onStateUpdated", false);
            XposedHelpers.callMethod(p.thisObject, "changeExpand");
            XposedHelpers.callMethod(p.thisObject, "showLabel", XposedHelpers.callMethod(p.thisObject, "getShowLabel"), p.args[1]);
            XposedHelpers.callMethod(p.thisObject, "updateMark", p.args[1]);
            p.setResult(null);
        }));

        hookAll(cl, "miui.systemui.controlcenter.panel.main.qs.QSItemViewHolder", "updateBlendBlur", before(p -> {
            Object item = XposedHelpers.callMethod(p.thisObject, "getQsItemView");
            View target = (View) XposedHelpers.callMethod(item, "getBlendTarget");
            Object state = XposedHelpers.getObjectField(item, "state");
            Object m = XposedHelpers.getObjectField(item, "mode");
            if (state == null) return;
            updateBlend(target, state, m == EDIT);
            p.setResult(null);
        }));

        hookAll(cl, "miui.systemui.controlcenter.qs.tileview.QSTileItemView", "updateState", before(p -> {
            if (p.args.length != 3) return;
            XposedHelpers.setObjectField(p.thisObject, "state", p.args[0]);
            Object state = p.args[0];
            Object m = XposedHelpers.getObjectField(p.thisObject, "mode");
            if (state != null && XposedHelpers.callMethod(p.thisObject, "getIcon") != null)
                updateBlend((View) XposedHelpers.callMethod(p.thisObject, "getBlendTarget"), state, m == EDIT);
            if (m != NORMAL) { p.setResult(null); return; }
            XposedHelpers.callMethod(p.thisObject, "onStateUpdated", p.args[2]);
            p.setResult(null);
        }));

        hookAll(cl, "miui.systemui.controlcenter.panel.main.qs.QSCardViewHolder", "updateBlendBlur", before(p -> {
            Object item = XposedHelpers.callMethod(p.thisObject, "getQsItemView");
            View target = (View) XposedHelpers.callMethod(item, "getBlendTarget");
            Object state = XposedHelpers.getObjectField(item, "state");
            if (state == null) return;
            updateBlend(target, state, false);
            p.setResult(null);
        }));

        hookAll(cl, "miui.systemui.controlcenter.qs.tileview.QSCardItemView", "updateBackground", after(p -> {
            initRes((Context) XposedHelpers.callMethod(p.thisObject, "getContext"));
            Object state = XposedHelpers.getObjectField(p.thisObject, "state");
            if (state == null) return;
            XposedHelpers.callStaticMethod(miBlur, "setMiBackgroundBlendColors", p.thisObject,
                    XposedHelpers.getIntField(state, "state") == 2 ? seekbarFgBlend : listItemsBlend);
        }));

        hookAll(cl, "com.android.systemui.miui.volume.MiuiRingerModeLayout$RingerButtonHelper", "updateState", before(p -> {
            ImageView icon = (ImageView) XposedHelpers.getObjectField(p.thisObject, "mIcon");
            View std = (View) XposedHelpers.getObjectField(p.thisObject, "mStandardView");
            boolean st = XposedHelpers.getBooleanField(p.thisObject, "mState");
            standardBtn.put(std, st);
            iconState.put(icon, st);
        }));

        hookAll(cl, "com.android.systemui.miui.volume.Util", "setMiViewBlurAndBlendColor", before(p -> {
            if (p.args.length == 6 && p.args[0] instanceof LinearLayout) {
                View v = (View) p.args[0];
                String name = v.getResources().getResourceEntryName(v.getId());
                if ("miui_standard_btn".equals(name)) {
                    Boolean s = standardBtn.get(v);
                    if (s != null && s) { initRes(v.getContext()); p.args[4] = ringerIconBlend; }
                }
            } else if (p.args.length == 3 && p.args[0] instanceof ImageView && ((Integer) p.args[1]) == 0) {
                ImageView iv = (ImageView) p.args[0];
                String name = iv.getResources().getResourceEntryName(iv.getId());
                if ("icon".equals(name)) {
                    Boolean s = iconState.get(iv);
                    if (s != null && s) { initRes(iv.getContext()); p.args[1] = 3; p.args[2] = seekbarRingerBgBlend; }
                }
            }
        }));
    }

    private static void initRes(Context ctx) {
        if (listItemsBlend != null && seekbarFgBlend != null && ringerIconBlend != null && seekbarRingerBgBlend != null) return;
        android.content.res.Resources r = ctx.getResources();
        String pkg = ctx.getPackageName();
        listItemsBlend = r.getIntArray(r.getIdentifier("control_center_list_items_blend_colors", "array", pkg));
        seekbarFgBlend = r.getIntArray(r.getIdentifier("miui_seekbar_fg_blend_colors_collapsed", "array", pkg));
        ringerIconBlend = r.getIntArray(r.getIdentifier("miui_ringer_icon_blend_colors_collapsed", "array", pkg));
        seekbarRingerBgBlend = r.getIntArray(r.getIdentifier("miui_seekbar_and_ringer_bg_blend_colors_collapsed", "array", pkg));
    }

    private static void updateBlend(View view, Object state, boolean edit) {
        if (view == null) return;
        int[] colors = edit || state == null || XposedHelpers.getIntField(state, "state") != 2 ? listItemsBlend : seekbarFgBlend;
        XposedHelpers.callStaticMethod(miBlur, "setMiBackgroundBlendColors", view, colors);
    }
}
