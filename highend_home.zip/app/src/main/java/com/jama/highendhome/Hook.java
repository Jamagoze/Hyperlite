package com.jama.highendhome;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import android.view.View;
import android.widget.TextView;
import android.util.TypedValue;
import dalvik.system.DexFile;
import java.io.File;
import java.io.FileWriter;
import java.lang.reflect.Method;
import java.util.Enumeration;

public class Hook implements IXposedHookLoadPackage {

    // from HyperCeiler config
    private static final boolean HIGH_END = true;          // home_other_high_models
    private static final boolean MIUI_WIDGETS = true;      // home_widget_show_miui_widget
    private static final float TITLE_SIZE_SP = 10f;        // home_title_font_size (0 = off)
    private static final boolean DUMP_CLASSES = true;      // writes <home data>/cache/home_classes.txt once

    private static final String[] BOOL_CLASSES = {
        "com.miui.home.launcher.MIUIWidgetUtil",
        "com.miui.home.launcher.widget.MIUIWidgetUtil",
        "com.miui.home.launcher.common.DeviceLevelUtils",
        "com.miui.home.launcher.DeviceConfig",
        "com.miui.home.launcher.common.Utilities",
        "com.miui.home.launcher.Application",
        "com.miui.home.recents.util.Utilities",
        "com.miui.home.launcher.util.DeviceLevelUtils",
        "com.miui.home.launcher.common.CpuLevelUtils",
        "com.miui.home.launcher.common.BlurUtils",
        "com.miui.home.launcher.graphics.BlurUtils"
    };

    private static final String[] CPU_CLASSES = {
        "com.miui.home.launcher.common.CpuLevelUtils",
        "com.miui.home.launcher.common.DeviceLevelUtils"
    };

    private static final String[] MIUI_BUILD_FALSE = {
        "IS_MIUI_LITE_VERSION", "IS_MIDDLE_DEVICE", "IS_LOW_MEMORY_DEVICE",
        "IS_LOW_END_DEVICE", "IS_MI_LITE_VERSION"
    };
    private static final String[] MIUI_BUILD_TRUE = {
        "IS_HIGH_END_DEVICE"
    };

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!"com.miui.home".equals(lp.packageName)) return;
        ClassLoader cl = lp.classLoader;

        if (HIGH_END) {
            for (String f : MIUI_BUILD_FALSE) setBuild(cl, f, false);
            for (String f : MIUI_BUILD_TRUE) setBuild(cl, f, true);
            for (String cn : BOOL_CLASSES) hookBooleans(cl, cn);
            for (String cn : CPU_CLASSES) hookLevels(cl, cn);
            hookDeviceLevel(cl);
        }
        if (TITLE_SIZE_SP > 0) hookTitleSize(cl);
        if (DUMP_CLASSES) dumpClasses(lp);
    }

    private void hookTitleSize(ClassLoader cl) {
        try {
            Class<?> c = XposedHelpers.findClass("com.miui.home.launcher.ItemIcon", cl);
            XposedBridge.hookAllMethods(c, "onFinishInflate", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        Object t = XposedHelpers.getObjectField(p.thisObject, "mTitle");
                        if (t instanceof TextView) ((TextView) t).setTextSize(TypedValue.COMPLEX_UNIT_SP, TITLE_SIZE_SP);
                    } catch (Throwable ignored) {}
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("HighEndHome title: " + t);
        }
    }

    private void dumpClasses(final XC_LoadPackage.LoadPackageParam lp) {
        final File out = new File(lp.appInfo.dataDir + "/cache/home_classes.txt");
        if (out.exists()) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String[] keys = {"Hotseat", "Recents", "Folder", "Widget", "DeviceConfig", "Utilities",
                            "Blur", "Dock", "Drawer", "Shortcut", "Gesture", "Animation", "ItemIcon",
                            "Title", "PersonalAssistant", "Wallpaper"};
                    DexFile df = new DexFile(lp.appInfo.sourceDir);
                    FileWriter w = new FileWriter(out);
                    Enumeration<String> e = df.entries();
                    int n = 0;
                    while (e.hasMoreElements() && n < 700) {
                        String cn = e.nextElement();
                        if (!cn.startsWith("com.miui.home")) continue;
                        boolean hit = false;
                        for (String k : keys) if (cn.contains(k)) { hit = true; break; }
                        if (!hit) continue;
                        n++;
                        w.write(cn + "\n");
                        try {
                            Class<?> c = Class.forName(cn, false, lp.classLoader);
                            for (Method m : c.getDeclaredMethods()) {
                                StringBuilder sb = new StringBuilder("  ").append(m.getReturnType().getSimpleName())
                                        .append(' ').append(m.getName()).append('(');
                                Class<?>[] pt = m.getParameterTypes();
                                for (int i = 0; i < pt.length; i++) { if (i > 0) sb.append(','); sb.append(pt[i].getSimpleName()); }
                                w.write(sb.append(")\n").toString());
                            }
                        } catch (Throwable ignored) {}
                    }
                    w.close();
                    out.setReadable(true, false);
                    XposedBridge.log("HighEndHome: wrote " + out);
                } catch (Throwable t) {
                    XposedBridge.log("HighEndHome dump: " + t);
                }
            }
        }).start();
    }

    private void setBuild(ClassLoader cl, String field, boolean v) {
        try {
            Class<?> c = XposedHelpers.findClass("miui.os.Build", cl);
            XposedHelpers.setStaticBooleanField(c, field, v);
        } catch (Throwable ignored) {}
    }

    private void hookBooleans(ClassLoader cl, String cn) {
        Class<?> c;
        try { c = XposedHelpers.findClass(cn, cl); } catch (Throwable t) { return; }
        for (Method m : c.getDeclaredMethods()) {
            if (m.getReturnType() != boolean.class) continue;
            if (m.getParameterTypes().length > 1) continue;
            String n = m.getName().toLowerCase();
            Boolean ret = null;
            boolean lowish = n.contains("lowlevel") || n.contains("lowend") || n.contains("lowmem")
                    || n.contains("lite") || n.contains("simpleanim") || n.contains("middledevice")
                    || n.contains("middlelevel") || n.contains("lowperformance") || n.contains("islow");
            boolean highish = n.contains("highend") || n.contains("highlevel") || n.contains("highperformance")
                    || n.contains("highmodel") || n.contains("ishigh");
            boolean feature = n.contains("supportblur") || n.contains("supportbackgroundblur")
                    || n.contains("isblursupport") || n.contains("supportcompleteanim")
                    || n.contains("supportmamlanim") || n.contains("supportadvancedanim")
                    || n.contains("supportshadow") || n.contains("supportsmoothcorner")
                    || n.contains("needmamlprogressbar") || n.contains("enableblur")
                    || (MIUI_WIDGETS && (n.contains("miuiwidgetsupport") || n.contains("supportmiuiwidget")));
            if (lowish) ret = Boolean.FALSE;
            else if (highish || feature) ret = Boolean.TRUE;
            if (ret == null) continue;
            try {
                XposedBridge.hookMethod(m, XC_MethodReplacement.returnConstant(ret));
            } catch (Throwable t) {
                XposedBridge.log("HighEndHome: " + cn + "." + m.getName() + " " + t);
            }
        }
    }

    private void hookLevels(ClassLoader cl, String cn) {
        Class<?> c;
        try { c = XposedHelpers.findClass(cn, cl); } catch (Throwable t) { return; }
        for (Method m : c.getDeclaredMethods()) {
            if (m.getReturnType() != int.class) continue;
            String n = m.getName().toLowerCase();
            if (n.contains("cpulevel") || n.equals("getdevicelevel") || n.contains("devicelevelforanim")
                    || n.contains("devicelevelforblur") || n.contains("devicelevelfortransition")) {
                try {
                    XposedBridge.hookMethod(m, XC_MethodReplacement.returnConstant(2));
                } catch (Throwable t) {
                    XposedBridge.log("HighEndHome: " + cn + "." + m.getName() + " " + t);
                }
            }
        }
    }

    private void hookDeviceLevel(ClassLoader cl) {
        try {
            Class<?> c = XposedHelpers.findClass("miui.util.DeviceLevel", cl);
            for (Method m : c.getDeclaredMethods()) {
                String n = m.getName().toLowerCase();
                if (m.getReturnType() == int.class && n.startsWith("getdevicelevel")) {
                    XposedBridge.hookMethod(m, XC_MethodReplacement.returnConstant(2));
                } else if (m.getReturnType() == boolean.class && (n.contains("islow") || n.contains("lite"))) {
                    XposedBridge.hookMethod(m, XC_MethodReplacement.returnConstant(false));
                }
            }
            for (String f : new String[]{"DEVICE_LEVEL"}) {
                try { XposedHelpers.setStaticIntField(c, f, 2); } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
    }
}
