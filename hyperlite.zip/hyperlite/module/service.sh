#!/system/bin/sh
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
sleep 5

# install verification off
settings put global package_verifier_enable 0
settings put global verifier_verify_adb_installs 0
settings put global package_verifier_user_consent -1
settings put global upload_apk_enable 0

# freeform windows
settings put global enable_freeform_support 1
settings put global force_resizable_activities 1
settings put global freeform_window_management 1

# hide gesture line
settings put global hide_gesture_line 1
