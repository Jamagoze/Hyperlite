#!/bin/bash
set -e
cd "$(dirname "$0")"
NDK="${ANDROID_NDK_LATEST_HOME:-${ANDROID_NDK_HOME:-$ANDROID_NDK_ROOT}}"
[ -f zygisk/src/zygisk.hpp ] || curl -fsSL https://raw.githubusercontent.com/topjohnwu/zygisk-module-sample/master/module/jni/zygisk.hpp -o zygisk/src/zygisk.hpp
mkdir -p module/zygisk
for abi in arm64-v8a armeabi-v7a; do
  cmake -S zygisk -B build/$abi \
    -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI=$abi -DANDROID_PLATFORM=android-26 -DCMAKE_BUILD_TYPE=Release
  cmake --build build/$abi -j
  cp build/$abi/libhyperlite.so module/zygisk/$abi.so
done
mkdir -p out && rm -f out/HyperLite.zip
(cd module && zip -r9 ../out/HyperLite.zip .)
