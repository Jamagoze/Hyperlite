#include <jni.h>
#include <cstring>
#include "zygisk.hpp"

namespace {

// Processes that must not see Magisk mounts (HyperCeiler: disable root check)
const char *kTargets[] = {
    "com.miui.securitycenter",
};

bool matches(const char *name) {
    for (const char *t : kTargets) {
        size_t n = strlen(t);
        if (strncmp(name, t, n) == 0 && (name[n] == 0 || name[n] == 58)) return true;
    }
    return false;
}

}  // namespace

class HyperLite : public zygisk::ModuleBase {
public:
    void onLoad(zygisk::Api *api, JNIEnv *env) override {
        api_ = api;
        env_ = env;
    }

    void preAppSpecialize(zygisk::AppSpecializeArgs *args) override {
        bool hit = false;
        if (args->nice_name) {
            const char *name = env_->GetStringUTFChars(args->nice_name, nullptr);
            if (name) {
                hit = matches(name);
                env_->ReleaseStringUTFChars(args->nice_name, name);
            }
        }
        if (hit) {
            api_->setOption(zygisk::FORCE_DENYLIST_UNMOUNT);
        } else {
            api_->setOption(zygisk::DLCLOSE_MODULE_LIBRARY);
        }
    }

    void preServerSpecialize(zygisk::ServerSpecializeArgs *) override {
        api_->setOption(zygisk::DLCLOSE_MODULE_LIBRARY);
    }

private:
    zygisk::Api *api_ = nullptr;
    JNIEnv *env_ = nullptr;
};

REGISTER_ZYGISK_MODULE(HyperLite)
