package com.jama.shothook;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
public class Hook implements IXposedHookLoadPackage {
private static final boolean SAVE_TO_PICTURES = true;
private static final boolean PRIVACY_MARKING = true;
@Override
public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
if (!"com.miui.screenshot".equals(lp.packageName)) return;
ClassLoader cl = lp.classLoader;
if (SAVE_TO_PICTURES) {
try {
Class<?> env = XposedHelpers.findClass("android.os.Environment", cl);
XposedHelpers.setStaticObjectField(env, "DIRECTORY_DCIM", "Pictures");
} catch (Throwable t) { XposedBridge.log("ShotHook pictures: " + t); }
}
if (PRIVACY_MARKING) {
Class<?> k = XposedHelpers.findClassIfExists("com.miui.gallery.editor.photo.screen.mosaic.ScreenMosaicView", cl);
if (k == null) { XposedBridge.log("ShotHook: ScreenMosaicView not found"); return; }
try {
XposedBridge.hookAllMethods(k, "isSupportPrivacyMarking", XC_MethodReplacement.returnConstant(true));
} catch (Throwable t) { XposedBridge.log("ShotHook privacy: " + t); }
}
}
}
