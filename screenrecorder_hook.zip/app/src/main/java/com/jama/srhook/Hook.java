package com.jama.srhook;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.List;
import org.luckypray.dexkit.DexKitBridge;
import org.luckypray.dexkit.query.FindClass;
import org.luckypray.dexkit.query.FindField;
import org.luckypray.dexkit.query.FindMethod;
import org.luckypray.dexkit.query.matchers.ClassMatcher;
import org.luckypray.dexkit.query.matchers.FieldMatcher;
import org.luckypray.dexkit.query.matchers.MethodMatcher;
import org.luckypray.dexkit.result.ClassData;
import org.luckypray.dexkit.result.FieldData;
import org.luckypray.dexkit.result.MethodData;
public class Hook implements IXposedHookLoadPackage {
private static final boolean CONFIG = true;
private static final boolean MORE_VOLUME = true;
@Override
public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
if (!"com.miui.screenrecorder".equals(lp.packageName)) return;
final ClassLoader cl = lp.classLoader;
DexKitBridge bridge = null;
try {
System.loadLibrary("dexkit");
bridge = DexKitBridge.create(lp.appInfo.sourceDir);
if (CONFIG) {
try { ranges(bridge, cl, "Error when set frame value, maxValue = ", new int[]{15, 24, 30, 48, 60, 90}, new int[]{15, 24, 30, 48, 60, 90, 120, 144}); }
catch (Throwable t) { XposedBridge.log("SRHook frame: " + t); }
try { ranges(bridge, cl, "defaultBitRate = ", new int[]{200, 100, 50, 32, 24, 16, 8, 6, 4, 1}, new int[]{1200, 800, 400, 200, 100, 50, 32, 24, 16, 8, 6, 4, 1}); }
catch (Throwable t) { XposedBridge.log("SRHook bitrate: " + t); }
}
if (MORE_VOLUME) {
try { moreVolume(bridge, cl); } catch (Throwable t) { XposedBridge.log("SRHook volume: " + t); }
}
} catch (Throwable t) {
XposedBridge.log("SRHook: " + t);
} finally {
if (bridge != null) bridge.close();
}
}
private void ranges(DexKitBridge b, ClassLoader cl, String str, final int[] from, final int[] to) throws Throwable {
MethodData md = b.findMethod(FindMethod.create().matcher(MethodMatcher.create().usingStrings(str))).singleOrNull();
if (md == null) { XposedBridge.log("SRHook: not found " + str); return; }
Method m = md.getMethodInstance(cl);
XposedBridge.hookMethod(m, new XC_MethodHook() {
@Override protected void beforeHookedMethod(MethodHookParam p) {
try {
if (p.args.length >= 2) { p.args[0] = 1200; p.args[1] = 1; }
for (Field f : p.method.getDeclaringClass().getDeclaredFields()) {
f.setAccessible(true);
if (Modifier.isFinal(f.getModifiers()) && Modifier.isStatic(f.getModifiers())) {
Object v = f.get(null);
if (v instanceof int[] && Arrays.equals((int[]) v, from)) { f.set(null, to); break; }
}
}
} catch (Throwable t) { XposedBridge.log("SRHook ranges: " + t); }
}
});
}
private void moreVolume(DexKitBridge b, ClassLoader cl) throws Throwable {
ClassData cd = b.findClass(FindClass.create().matcher(ClassMatcher.create().usingStrings("support_a2dp_inner_record"))).singleOrNull();
if (cd != null) {
final Class<?> cls = cd.getInstance(cl);
List<FieldData> fields = b.findField(FindField.create().matcher(FieldMatcher.create().declaredClass(cls).type("boolean")));
final String[] names = new String[fields.size()];
for (int i = 0; i < names.length; i++) names[i] = fields.get(i).getName();
XposedBridge.hookAllConstructors(cls, new XC_MethodHook() {
@Override protected void afterHookedMethod(MethodHookParam p) {
for (String n : names) {
try { XposedHelpers.setObjectField(p.thisObject, n, true); } catch (Throwable ignored) {}
}
}
});
}
MethodData md = b.findMethod(FindMethod.create().matcher(MethodMatcher.create().usingStrings("ro.vendor.audio.screenrecorder.bothrecord"))).singleOrNull();
if (md != null) XposedBridge.hookMethod(md.getMethodInstance(cl), XC_MethodReplacement.returnConstant(1));
}
}
