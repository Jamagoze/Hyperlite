package com.jama.fwhook;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class Hook implements IXposedHookLoadPackage {

    // toggles (from HyperCeiler config)
    private static final boolean DISABLE_SAFE_VOLUME = true;  // system_framework_volume_disable_safe_new
    private static final boolean DISABLE_72H_VERIFY  = true;  // system_framework_disable_72h_verify

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!"android".equals(lp.packageName)) return;
        ClassLoader cl = lp.classLoader;

        if (DISABLE_SAFE_VOLUME) {
            Class<?> audio = XposedHelpers.findClassIfExists("com.android.server.audio.AudioService", cl);
            if (audio != null) {
                try { XposedBridge.hookAllMethods(audio, "checkSafeMediaVolume", XC_MethodReplacement.returnConstant(true)); } catch (Throwable t) { log(t); }
                try { XposedBridge.hookAllMethods(audio, "enforceSafeMediaVolume", XC_MethodReplacement.returnConstant(null)); } catch (Throwable t) { log(t); }
            }
        }

        if (DISABLE_72H_VERIFY) {
            Class<?> sa = XposedHelpers.findClassIfExists("com.android.server.locksettings.LockSettingsStrongAuth", cl);
            if (sa != null) {
                for (String m : new String[]{"rescheduleStrongAuthTimeoutAlarm", "handleScheduleStrongAuthTimeout"}) {
                    try { XposedBridge.hookAllMethods(sa, m, XC_MethodReplacement.returnConstant(null)); } catch (Throwable t) { log(t); }
                }
            }
        }
    }

    private static void log(Throwable t) { XposedBridge.log("FrameworkHook: " + t); }
}
