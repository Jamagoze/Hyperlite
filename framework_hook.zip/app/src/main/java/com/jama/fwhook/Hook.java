package com.jama.fwhook;
import android.content.Context;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
public class Hook implements IXposedHookLoadPackage {
private static final boolean DISABLE_72H = true;
private static final boolean SAFE_VOLUME = true;
private static final boolean SPEED_INSTALL = true;
private static final boolean NO_MIUI_LITE = true;
private static final boolean LOW_API = true;
private static final boolean NO_PERSISTENT = true;
private static final boolean ANDROID_INSTALLER = true;
private static final boolean QUICK_SCREENSHOT = true;
private static final boolean FREEFORM_COUNT = true;
private static final boolean FREEFORM_BUBBLE = true;
private static final boolean FREEFORM_BLACKLIST = true;
private static final boolean FOREGROUND_PIN = true;
private static final boolean THIRD_THEME = true;
private static final boolean NO_CLEANER = true;
private static final boolean NO_GESTURE_MONITOR = true;
private static final boolean HOOK_ENTRY = true;
private static final boolean PROTECTED_PACKAGE = true;
private ClassLoader cl;
private boolean installing;
private boolean fakeCts;
private boolean protectedHooked;
private interface Fn { void run(XC_MethodHook.MethodHookParam p) throws Throwable; }
private static XC_MethodHook before(final Fn f) {
return new XC_MethodHook() {
@Override protected void beforeHookedMethod(MethodHookParam p) {
try { f.run(p); } catch (Throwable t) { XposedBridge.log("FrameworkHook: " + t); }
}
};
}
private static XC_MethodHook after(final Fn f) {
return new XC_MethodHook() {
@Override protected void afterHookedMethod(MethodHookParam p) {
try { f.run(p); } catch (Throwable t) { XposedBridge.log("FrameworkHook: " + t); }
}
};
}
private Class<?> c(String n) { return XposedHelpers.findClassIfExists(n, cl); }
private void hk(String cn, String m, XC_MethodHook h) {
Class<?> k = c(cn);
if (k == null) { XposedBridge.log("FrameworkHook: missing class " + cn); return; }
try {
if (XposedBridge.hookAllMethods(k, m, h).isEmpty()) XposedBridge.log("FrameworkHook: no method " + cn + "." + m);
} catch (Throwable t) { XposedBridge.log("FrameworkHook: " + cn + "." + m + " " + t); }
}
private void run(String name, Runnable r) {
try { r.run(); } catch (Throwable t) { XposedBridge.log("FrameworkHook " + name + ": " + t); }
}
@Override
public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
if (!"android".equals(lp.packageName)) return;
cl = lp.classLoader;
XC_MethodHook nothing = XC_MethodReplacement.returnConstant(null);
if (DISABLE_72H) run("72h", () -> hk("com.android.server.locksettings.LockSettingsStrongAuth", "rescheduleStrongAuthTimeoutAlarm", nothing));
if (SAFE_VOLUME) run("volume", this::safeVolume);
if (SPEED_INSTALL) run("speedInstall", () -> hk("android.content.pm.PackageInstaller", "isSupportedSpeedInstallV2", XC_MethodReplacement.returnConstant(true)));
if (NO_MIUI_LITE) run("lite", this::noMiuiLite);
if (LOW_API) run("lowApi", this::lowApi);
if (NO_PERSISTENT) run("persistent", this::noPersistent);
if (ANDROID_INSTALLER) run("installer", this::androidInstaller);
if (QUICK_SCREENSHOT) run("screenshot", () -> hk("com.android.server.policy.PhoneWindowManager", "getScreenshotChordLongPressDelay", XC_MethodReplacement.returnConstant(0L)));
if (FREEFORM_COUNT) run("ffCount", () -> {
hk("com.android.server.wm.MiuiFreeFormStackDisplayStrategy", "getMaxMiuiFreeFormStackCount", XC_MethodReplacement.returnConstant(256));
hk("com.android.server.wm.MiuiFreeFormStackDisplayStrategy", "getMaxMiuiFreeFormStackCountForFlashBack", XC_MethodReplacement.returnConstant(256));
});
if (FREEFORM_BUBBLE) run("ffBubble", () -> hk("android.util.MiuiMultiWindowUtils", "multiFreeFormSupported", XC_MethodReplacement.returnConstant(true)));
if (FREEFORM_BLACKLIST) run("ffBlacklist", this::freeformBlacklist);
if (FOREGROUND_PIN) run("pin", () -> hk("com.android.server.wm.MiuiFreeFormGestureController", "needForegroundPin", XC_MethodReplacement.returnConstant(true)));
if (THIRD_THEME) run("theme", this::thirdTheme);
if (NO_CLEANER) run("cleaner", this::noCleaner);
if (NO_GESTURE_MONITOR) run("gesture", () -> hk("com.miui.server.input.gesture.MiuiGestureMonitor", "registerPointerEventListener", nothing));
if (HOOK_ENTRY) run("entry", () -> hk("com.android.server.MiuiBatteryIntelligence$BatteryNotificationListernerService", "isNavigationStatus", XC_MethodReplacement.returnConstant(true)));
if (PROTECTED_PACKAGE) run("protected", this::protectedPackage);
}
private void safeVolume() {
String stub = c("com.android.server.audio.SoundDoseHelperStub") != null
? "com.android.server.audio.SoundDoseHelperStub" : "com.android.server.audio.SoundDoseHelperStubImpl";
hk(stub, "updateSafeMediaVolumeIndex", XC_MethodReplacement.returnConstant(2147483646));
hk("com.android.server.audio.SoundDoseHelper", "safeMediaVolumeIndex", XC_MethodReplacement.returnConstant(2147483646));
}
private void noMiuiLite() {
hk("miui.os.Build", "isMiuiLiteVersion", XC_MethodReplacement.returnConstant(false));
Class<?> d = c("miui.util.DeviceLevel");
if (d == null) return;
for (String f : new String[]{"IS_MIUI_GO_VERSION", "IS_MIUI_LITE_VERSION", "IS_MIUI_MIDDLE_VERSION"}) {
try { XposedHelpers.setStaticBooleanField(d, f, false); } catch (Throwable ignored) {}
}
}
private void lowApi() {
hk("com.android.server.pm.InstallPackageHelper", "preparePackageLI", before(p -> {
Object args = XposedHelpers.getObjectField(p.args[0], "mInstallArgs");
if (args == null) return;
XposedHelpers.setIntField(args, "mInstallFlags", XposedHelpers.getIntField(args, "mInstallFlags") | 0x01000000);
}));
}
private void noPersistent() {
hk("com.android.server.pm.parsing.pkg.PackageImpl", "isPersistent", after(p -> {
if (installing && Boolean.TRUE.equals(p.getResult())) p.setResult(false);
}));
hk("com.android.server.pm.InstallPackageHelper", "preparePackageLI", new XC_MethodHook() {
@Override protected void beforeHookedMethod(MethodHookParam p) { installing = true; }
@Override protected void afterHookedMethod(MethodHookParam p) { installing = false; }
});
}
private void androidInstaller() {
Class<?> k = c("com.android.server.pm.PackageManagerServiceImpl");
if (k == null) return;
hk("com.android.server.pm.PackageManagerServiceImpl", "isCTS", before(p -> p.setResult(fakeCts)));
XC_MethodHook h = new XC_MethodHook() {
@Override protected void beforeHookedMethod(MethodHookParam p) { fakeCts = true; }
@Override protected void afterHookedMethod(MethodHookParam p) { fakeCts = false; }
};
for (Method m : k.getDeclaredMethods()) {
String n = m.getName();
if (n.equals("hookChooseBestActivity") || n.equals("updateDefaultPkgInstallerLocked") || n.equals("assertValidApkAndInstaller")) {
try { XposedBridge.hookMethod(m, h); } catch (Throwable t) { XposedBridge.log("FrameworkHook installer: " + t); }
}
}
}
@SuppressWarnings("unchecked")
private void freeformBlacklist() {
String a = "android.util.MiuiMultiWindowAdapter";
XC_MethodHook clear = after(p -> {
Object r = p.getResult();
if (r instanceof List) ((List<String>) r).clear();
});
hk(a, "getFreeformBlackList", clear);
hk(a, "getFreeformBlackListFromCloud", clear);
hk(a, "setFreeformBlackList", before(p -> {
List<String> l = new ArrayList<>();
l.add("ab.cd.xyz");
p.args[0] = l;
}));
hk("android.util.MiuiMultiWindowUtils", "isForceResizeable", XC_MethodReplacement.returnConstant(true));
hk("android.util.MiuiMultiWindowUtils", "supportFreeform", XC_MethodReplacement.returnConstant(true));
hk("com.android.server.wm.ActivityTaskManagerService", "retrieveSettings", after(p ->
XposedHelpers.setBooleanField(p.thisObject, "mDevEnableNonResizableMultiWindow", true)));
XC_MethodHook obs = after(p -> {
Object outer = XposedHelpers.getObjectField(p.thisObject, "this$0");
Object atm = XposedHelpers.getObjectField(outer, "mAtmService");
XposedHelpers.setBooleanField(atm, "mDevEnableNonResizableMultiWindow", true);
});
hk("com.android.server.wm.WindowManagerService$SettingsObserver", "updateDevEnableNonResizableMultiWindow", obs);
hk("com.android.server.wm.WindowManagerService$SettingsObserver", "onChange", obs);
}
private void thirdTheme() {
final Object[][] holder = new Object[1][];
hk("miui.drm.ThemeReceiver", "validateTheme", new XC_MethodHook() {
@Override protected void beforeHookedMethod(MethodHookParam p) {
try {
Class<?> drm = c("miui.drm.DrmManager");
Class<?> res = c("miui.drm.DrmManager$DrmResult");
Object ok = XposedHelpers.getStaticObjectField(res, "DRM_SUCCESS");
holder[0] = XposedBridge.hookAllMethods(drm, "isLegal", XC_MethodReplacement.returnConstant(ok)).toArray();
} catch (Throwable t) { XposedBridge.log("FrameworkHook theme: " + t); }
}
@Override protected void afterHookedMethod(MethodHookParam p) {
if (holder[0] != null) for (Object u : holder[0]) ((XC_MethodHook.Unhook) u).unhook();
holder[0] = null;
}
});
}
private void noCleaner() {
XC_MethodHook nothing = XC_MethodReplacement.returnConstant(null);
hk("com.android.server.am.ActivityManagerService", "checkExcessivePowerUsage", nothing);
hk("com.android.server.am.ActivityManagerShellCommand", "runKillAll", nothing);
hk("com.android.server.am.CameraBooster", "boostCameraIfNeeded", nothing);
hk("com.android.server.am.OomAdjuster", "shouldKillExcessiveProcesses", XC_MethodReplacement.returnConstant(false));
hk("com.android.server.am.OomAdjuster", "updateAndTrimProcessLSP", before(p -> { if (p.args.length > 2) p.args[2] = 0; }));
hk("com.android.server.am.PhantomProcessList", "trimPhantomProcessesIfNecessary", nothing);
hk("com.android.server.am.ProcessMemoryCleaner", "checkBackgroundProcCompact", nothing);
hk("com.android.server.am.ProcessPowerCleaner", "handleAutoLockOff", nothing);
hk("com.android.server.am.SystemPressureController", "nStartPressureMonitor", nothing);
hk("com.android.server.wm.RecentTasks", "trimInactiveRecentTasks", nothing);
hk("com.miui.cameraopt.adapter.ProcessManagerAdapter", "killApplication", nothing);
}
private void protectedPackage() {
hk("com.android.server.pm.PackageManagerService", "setEnabledSettings", before(p -> {
if (protectedHooked) return;
protectedHooked = true;
hk("com.android.server.pm.ProtectedPackages", "isPackageStateProtected", XC_MethodReplacement.returnConstant(false));
}));
}
}
